"""
File: draw_triangles.py
--------------------
This program draws triangles on the canvas using a function that can draw 1 triangle.
"""

from graphics import Canvas


def main():
    canvas = Canvas()
    canvas.set_canvas_title("Draw Triangles")

    # TODO: your code here

    canvas.mainloop()


if __name__ == '__main__':
    main()
