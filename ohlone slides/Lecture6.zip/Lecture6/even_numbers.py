"""
Print the even numbers between 10 and 15.
"""


def main():
    print("The the even numbers between 10 and 14:")
    for i in range(10, 15, 2):
        print(i)


if __name__ == '__main__':
    main()