from karel.stanfordkarel import *

"""
File: place_100.py
------------------------
This program makes Karel place a pile of 100 beepers. Good times.
"""


def main():
    """
    When you start your program, this code will be executed.
    """
    pass


# There is no need to edit code beyond this point

if __name__ == "__main__":
    run_karel_program()
