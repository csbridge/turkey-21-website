# This program displays a label with text.

from graphics import Canvas


def main():
    pass


if __name__ == "__main__":
    main()
