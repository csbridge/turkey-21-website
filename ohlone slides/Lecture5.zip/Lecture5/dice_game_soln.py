import random

GOAL_IN_A_ROW = 3
GOAL_VALUE = 6
MAX_DICE = 6
MIN_DICE = 1

def main():
    # how many dice rolls until you get three sixes in a row?
    num_dice_rolls = 0
    sixes_in_a_row = 0
    while sixes_in_a_row < GOAL_IN_A_ROW:
        dice_value = random.randint(MIN_DICE, MAX_DICE)
        print('You rolled a ' + str(dice_value))
        if dice_value == GOAL_VALUE:
            sixes_in_a_row = sixes_in_a_row + 1
        else:
            sixes_in_a_row = 0
        num_dice_rolls += 1
    print('Number of times rolled = ' + str(num_dice_rolls))

# This provided line is required at the end of a Python file
# to call the main() function.
if __name__ == '__main__':
    main()