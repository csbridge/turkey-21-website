"""
File: print_indices.py
-------------------
This program prints out the indices of a 5x5 grid, row by row.
"""


def main():
    # TODO: your code here (remove the 'pass' when you start)
    pass


if __name__ == '__main__':
    main()
