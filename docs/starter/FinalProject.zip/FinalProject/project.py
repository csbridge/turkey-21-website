"""
File: project.py
-----------------
This program is an empty program for your final project.  Update this comment
with a summary of your program!
"""

from graphics import Canvas


def main():
    # Feel free to remove this graphics code if you are not using graphics
    canvas = Canvas()
    canvas.set_canvas_title("Final Project")

    # TODO: your code here!

    canvas.mainloop()


if __name__ == '__main__':
    main()
