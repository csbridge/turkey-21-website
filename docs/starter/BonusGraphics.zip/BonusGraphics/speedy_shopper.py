"""
File: speedy_shopper.py
--------------------
This program prints out the cost for items in a store with certain discounts.
"""


def main():
    print(calculate_price(100.32, 0.25))
    print(calculate_price(53.27, 0.15))


# TODO: add the calculate_price function here!


if __name__ == '__main__':
    main()
