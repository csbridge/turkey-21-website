"""
File: border_box.py
--------------------
This program animates a box moving around the border of the screen forever.
"""

from graphics import Canvas
import time

# The size of the canvas
CANVAS_WIDTH = 500
CANVAS_HEIGHT = 500

# The dimensions of the box
BOX_SIZE = 32

# The amount the box should move each frame in addition to its size
BOX_GAP_SIZE = 4

# Represent the directions as numbers
EAST = 1
SOUTH = 2
WEST = 3
NORTH = 4

ANIMATION_DELAY_SECONDS = 0.2


def main():
    canvas = Canvas(CANVAS_WIDTH, CANVAS_HEIGHT)
    canvas.set_canvas_title("Border Box")

    # TODO: your code here

    canvas.mainloop()


if __name__ == '__main__':
    main()
