"""
File: countdown.py
--------------------
This program displays a large text countdown timer in the center of the
screen and displays an end message when the timer is up.
"""

from graphics import Canvas
import time

# The size of the canvas
CANVAS_WIDTH = 600
CANVAS_HEIGHT = 400

# Font information for the countdown numbers and final message
COUNTDOWN_TEXT_FONT_NAME = "Monaco"
COUNTDOWN_TEXT_FONT_SIZE = 200
END_MESSAGE_FONT_SIZE = 60

# The number of seconds to count down
COUNTDOWN_SECONDS = 10

ANIMATION_DELAY_SECONDS = 1


def main():
    canvas = Canvas(CANVAS_WIDTH, CANVAS_HEIGHT)
    canvas.set_canvas_title("Number Grid")

    # TODO: your code here

    canvas.mainloop()


if __name__ == '__main__':
    main()
