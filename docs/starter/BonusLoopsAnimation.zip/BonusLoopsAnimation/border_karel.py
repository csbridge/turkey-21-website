from karel.stanfordkarel import *

"""
File: border_karel.py
---------------------
This program has Karel move around the border of the world forever.
"""


def main():
    # TODO: your code here (remove the "pass" when you start)
    pass


# There is no need to edit code beyond this point

if __name__ == "__main__":
    run_karel_program()
