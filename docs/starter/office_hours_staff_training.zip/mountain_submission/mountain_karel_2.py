from karel.stanfordkarel import *

"""
File: mountain_karel.py
------------------------------
At present, this file does nothing. Your job is to place
a beeper at the top of the mountain. You should make sure
that your program works for all of the sample mountain worlds
supplied in the starter folder.

NOTE: there is a *BUG* in this implementation!  Karel is supposed to climb to the
top of the mountain and put a beeper there.  But instead, Karel seems to keep climbing...
"""


def main():
    ascend_mountain()
    put_beeper()


def ascend_mountain():
    """
    Karel climbs to the top of the mountain one step at a time.
    Karel starts at the bottom of the mountain, facing east, and should
    end up at the top of the mountain, facing east.
    """
    turn_left()
    while front_is_clear():
        move()
        turn_right()
        move()
        turn_left()


def turn_right():
    turn_left()
    turn_left()
    turn_left()


# There is no need to edit code beyond this point

if __name__ == "__main__":
    run_karel_program()
