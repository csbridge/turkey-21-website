from karel.stanfordkarel import *

"""
File: mountain_karel.py
------------------------------
At present, this file does nothing. Your job is to place
a beeper at the top of the mountain. You should make sure
that your program works for all of the sample mountain worlds
supplied in the starter folder.
"""


def main():
    turn_left()
    move()
    turn_right()
    move()


def turn_right():
    turn_left()
    turn_left()
    turn_left()


# There is no need to edit code beyond this point

if __name__ == "__main__":
    run_karel_program()
