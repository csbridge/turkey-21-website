"""
File: move_to_center.py
------------------------
This program draws an optical illusion of a checkerboard pattern.
"""

from graphics import Canvas
import time

CANVAS_WIDTH = 540
CANVAS_HEIGHT = 430

BALL_SIZE = 30
DELAY = 1 / 10


def main():
    canvas = Canvas(CANVAS_WIDTH, CANVAS_HEIGHT)
    canvas.set_canvas_title("Move to center")

    ball = make_ball(canvas)

    while True:
        # move world for one heartbeat

        canvas.update()
        time.sleep(DELAY)

    canvas.mainloop()

def make_ball(canvas):
    # this function creates a blue ball, and returns it!
    ball = canvas.create_oval(0, 0, BALL_SIZE, BALL_SIZE)
    canvas.set_color(ball, 'blue')
    return ball

if __name__ == '__main__':
    main()
