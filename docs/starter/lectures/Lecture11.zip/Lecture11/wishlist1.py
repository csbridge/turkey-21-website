def main():
    wish = input("Enter your wish: ")
    # do something with your wish
    print("Your wish is " + wish)


if __name__ == '__main__':
    main()
