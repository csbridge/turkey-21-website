"""
File: wishlist.py
---------------------
This program exemplifies the use of lists for reading a number of inputs from
the user and printing them. The program asks for new input until the user clicks
enter without typing a wish. Then program prints that some of the wishes will be fulfilled.
"""
import random


def main():
    # Creating an empty list as container of wishes
    wish_list = []
    # Read the first wish
    wish = input("Enter your wish: ")
    # TODO: implement rest of the program



if __name__ == '__main__':
    main()
