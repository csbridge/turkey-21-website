"""
CS Bridge 2020
The program captures data about people and their age using dictionaries
Author: Ayca Tuzmen
"""

def main():
    #create dic

    #print dic

    #print sorted names

    #print sorted ages

    pass

if __name__ == '__main__':
    main()