def sum_squares():
	a = float(input('Enter a number:  '))
	b = float(input('Enter a number:  '))
	result = a**2 + b**2
	print(result)

sum_squares()
