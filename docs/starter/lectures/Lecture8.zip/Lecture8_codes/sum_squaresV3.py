def sum_squares(a,b):
	result = a**2 + b**2
	return result

a = float(input('Enter a number:  '))
b = float(input('Enter a number:  '))

print(sum_squares(a,b))
