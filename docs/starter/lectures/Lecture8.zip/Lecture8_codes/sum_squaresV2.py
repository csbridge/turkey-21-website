def sum_squares():
	a = float(input('Enter a number:  '))
	b = float(input('Enter a number:  '))
	result = a**2 + b**2
	return result

print(sum_squares())
