"""
File: draw_car.py
-----------------------
Draws a car in the top left corner of the screen
"""
from graphics import Canvas


def main():
    canvas = Canvas()
    canvas.set_canvas_title("Car")

    # TODO: your code here!

    canvas.mainloop()


if __name__ == "__main__":
    main()
