"""
File: programming_is_awesome.py
--------------------
This program draws various art on the canvas using graphics!
"""

from graphics import Canvas


def main():
    """
    You should write your code between the two lines written
    already that set up the canvas.
    You should replace this comment with a better, more descriptive one.
    """
    canvas = Canvas()
    canvas.set_canvas_title("Programming is Awesome!")

    # TODO: your code here

    canvas.mainloop()


if __name__ == '__main__':
    main()
